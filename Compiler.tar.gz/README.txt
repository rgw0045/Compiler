Programmers: Ricardo Wiggins
			 Anthony Adewole

Instructions: type make and an executable will be created.
			  Then Type executable < inputFile to run compiler with input
